package com.aimlock.ob55;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new GameBridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    private class GameBridge {
        @JavascriptInterface
        public void launchGame(String which) {
            final String pkg = "max".equalsIgnoreCase(which)
                    ? "com.dts.freefiremax"
                    : "com.dts.freefireth";
            runOnUiThread(() -> {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (launch != null) {
                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(launch);
                    } else {
                        String name = "max".equalsIgnoreCase(which) ? "Free Fire MAX" : "Free Fire";
                        webView.evaluateJavascript("showToast('" + name + " chưa được cài đặt')", null);
                    }
                } catch (Exception e) {
                    webView.evaluateJavascript("showToast('Không thể mở game')", null);
                }
            });
        }
    }
}
